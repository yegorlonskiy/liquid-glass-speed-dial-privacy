// Автор: Yegor Lonskiy. Упаковываем локальные кодеки без загрузок во время работы.
import fs from 'node:fs/promises';
import path from 'node:path';
import ts from 'typescript';
const root=path.resolve(import.meta.dirname,'..');
const out=path.join(root,'public/codecs'); await fs.mkdir(out,{recursive:true});
// WASM импортируется из исходников через Vite и больше не дублируется в public.
for(const name of ['avif_enc.wasm','avif_dec.wasm','jxl_enc.wasm','jxl_dec.wasm','oxipng.wasm','resize.wasm'])await fs.rm(path.join(out,name),{force:true});

// В библиотеке HEIF поток задан строкой. При сборке выносим его в обычный локальный файл.
// Это позволяет использовать строгую политику расширения без динамических скриптов.
const source=await fs.readFile(path.join(root,'node_modules/heic-to/dist/csp/heic-to.js'),'utf8');
const ast=ts.createSourceFile('heic-to.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
let worker='';
function visit(n) { if(ts.isStringLiteral(n) && n.text.length>100000) worker=n.text; ts.forEachChild(n,visit); }
visit(ast);
const library=/var (\w+)=(\w+)\(\),yb=/;
if(!worker || !library.test(worker) || !worker.includes('onmessage=')) throw Error('Структура HEIF изменилась. Нужно обновить адаптер.');
worker=worker.replace(library,(_,lib,factory)=>`var ${lib}=${factory}();globalThis.GlassHeif=${lib};var yb=`);
worker=worker.slice(0,worker.lastIndexOf('onmessage='))+'});Yb();})();';
await fs.writeFile(path.join(out,'heif.js'),'/* Адаптация: Yegor Lonskiy. Основа: heic-to, LGPL-3.0. См. licenses. */\n'+worker);
