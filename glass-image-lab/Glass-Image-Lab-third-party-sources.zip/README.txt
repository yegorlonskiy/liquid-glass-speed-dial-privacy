Автор адаптера: Yegor Lonskiy. Оригинальное авторство библиотек сохранено.

HEIF sources used by Glass Image Lab 0.2.1

The upstream archives contain heic-to 1.6.7, libheif 1.23.7 and libde265 1.0.16. See upstream/SOURCES.json for original URLs and SHA-256 checksums; each archive retains its upstream build files and license notices. No upstream C/C++ codec changes were made.

To reproduce the local JavaScript library from the published heic-to package: install Node.js, run npm install in this directory, then node scripts/rebuild-heif.mjs. The result is public/codecs/heif.js. This extracts the CSP worker source, exposes globalThis.GlassHeif and removes its original message handler. The adapter is licensed under LGPL-3.0-or-later.

To use a modified library, unpack the extension ZIP, replace codecs/heif.js while preserving the public GlassHeif interface, and load the directory as an unpacked extension in Edge. The application and library are separate scripts; no application source changes are required to replace an interface-compatible library. The application license permits modification and replacement of this LGPL component and debugging of those modifications.

Для повторной сборки локальной библиотеки установите Node.js, выполните npm install, затем node scripts/rebuild-heif.mjs. Готовый файл public/codecs/heif.js заменяет codecs/heif.js в распакованном расширении. Сохраните интерфейс GlassHeif и загрузите папку как распакованное расширение в Edge. Адаптер распространяется под LGPL-3.0-or-later.
